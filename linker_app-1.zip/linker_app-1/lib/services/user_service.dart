class UserService {
  static Map? currentUserData;
}
