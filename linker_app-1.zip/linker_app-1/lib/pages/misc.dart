import 'package:flutter/material.dart';

class AboutUsDetails extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("About Us Details"),
        backgroundColor: Colors.purpleAccent,
      ),
      body: const Center(
        child: Text("About Us Details Screen"),
      ),
    );
  }
}

class PrivacyPolicyDetails extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Privacy Policy Details"),
        backgroundColor: Colors.purpleAccent,
      ),
      body: const Center(
        child: Text("Privacy Policy Details Screen"),
      ),
    );
  }
}

class TermsAndConditionsDetails extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Terms and Conditions Details"),
        backgroundColor: Colors.purpleAccent,
      ),
      body: const Center(
        child: Text("Terms and Conditions Details Screen"),
      ),
    );
  }
}

class MyScheduleDetails extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("My Schedule Details"),
        backgroundColor: Colors.purpleAccent,
      ),
      body: const Center(
        child: Text("My Schedule Details Screen"),
      ),
    );
  }
}
