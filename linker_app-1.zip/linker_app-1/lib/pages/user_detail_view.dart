import 'package:flutter/material.dart';
import 'package:linker_app/pages/mentor/view_schedule.dart';

class UserDetailScreen extends StatelessWidget {
  final String username, id;
  final String email;
  final String phoneNumber;
  final String userType;
  final String areaOfExpertise;
  final String bio;
  final String profileImageUrl; // New field
  final Map userData;

  const UserDetailScreen({
    Key? key,
    required this.username,
    required this.id,
    required this.email,
    required this.phoneNumber,
    required this.userType,
    required this.areaOfExpertise,
    required this.bio,
    required this.profileImageUrl, // Updated constructor
    required this.userData,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('User Detail'),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: CircleAvatar(
                  radius: 40,
                  backgroundImage:
                      NetworkImage(profileImageUrl), // Use network image
                ),
              ),
              const SizedBox(height: 20),
              const Text(
                'Profile Information',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 20),
              _buildDetailRow('Username', username),
              _buildDetailRow('Email', email),
              _buildDetailRow('Phone Number', phoneNumber),
              _buildDetailRow('User Type', userType),
              _buildDetailRow('Area of Expertise', areaOfExpertise),
              _buildDetailRow('Bio', bio),
              const SizedBox(
                height: 20,
              ),
              if (userData['userType'] == 'Mentor')
                Align(
                  child: ElevatedButton(
                    onPressed: () {
                      print(userData);
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => ViewSchedule(
                            price: userData['costPerSession'],
                            schedule: userData['availability'] ?? [],
                            id: id,
                          ),
                        ),
                      );
                    },
                    child: const Text("Book a Schedule"),
                  ),
                )
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: Colors.grey[700]),
        ),
        const SizedBox(height: 5),
        Text(
          value,
          style: const TextStyle(fontSize: 18, color: Colors.black),
        ),
        const SizedBox(height: 15),
        Divider(
          color: Colors.grey[300],
          thickness: 1,
        ),
      ],
    );
  }
}
