import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_storage/firebase_storage.dart' as firebase_storage;
import 'package:linker_app/pages/user_list_view.dart';

class ProfileCreationPage extends StatefulWidget {
  const ProfileCreationPage({Key? key, required this.userType})
      : super(key: key);
  final String userType;

  @override
  _ProfileCreationPageState createState() => _ProfileCreationPageState();
}

class _ProfileCreationPageState extends State<ProfileCreationPage> {
  String areaOfExpertise = '';
  String costPerSession = '';
  String bio = '';
  String? gender;
  File? _image;
  bool isLoading = false;

  final picker = ImagePicker();

  List selectedSchedule = [];

  Future<void> _getImage() async {
    final pickedFile = await picker.getImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      setState(() {
        _image = File(pickedFile.path);
      });
    }
  }

  void _saveProfileToFirestore() async {
    setState(() {
      isLoading = true;
    });
    try {
      if (widget.userType == 'Mentor' && selectedSchedule.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Please select at least 1 day'),
            duration: Duration(seconds: 2),
          ),
        );
      } else {
        String userId = FirebaseAuth.instance.currentUser!.uid;

        // Create a reference to the user's document
        DocumentReference userRef =
            FirebaseFirestore.instance.collection('users').doc(userId);

        // Create a map with the fields to update
        Map<String, dynamic> userData = {
          'areaOfExpertise': areaOfExpertise,
          'costPerSession': costPerSession,
          'bio': bio,
          'gender': gender,
          'availability': selectedSchedule,
          // Add more fields as needed
        };

        // Check if an image is selected
        if (_image != null) {
          // Upload the image to Firebase Storage
          String imageUrl = await uploadImageToStorage(_image!);

          // Add the image URL to the user data
          userData['imageUrl'] = imageUrl;
        }

        // Update the user document in Firestore
        await userRef.update(userData);

        // Display a success message
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Profile updated successfully!'),
            duration: Duration(seconds: 2),
          ),
        );

        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => const UserListScreen()),
        );
      }
    } catch (error) {
      // Handle any errors
      print('Failed to update profile: $error');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to update profile: $error'),
          duration: Duration(seconds: 2),
        ),
      );
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }

  Future<String> uploadImageToStorage(File imageFile) async {
    try {
      String userId = FirebaseAuth.instance.currentUser!.uid;
      String fileName = 'profile_$userId.jpg';

      // Upload the image file to Firebase Storage
      firebase_storage.Reference ref = firebase_storage.FirebaseStorage.instance
          .ref()
          .child('images/$fileName');
      firebase_storage.UploadTask uploadTask = ref.putFile(imageFile);
      firebase_storage.TaskSnapshot snapshot =
          await uploadTask.whenComplete(() {});
      String downloadUrl = await snapshot.ref.getDownloadURL();

      return downloadUrl;
    } catch (error) {
      // Handle any errors
      print('Failed to upload image: $error');
      throw error;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Complete Your Profile'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            GestureDetector(
              onTap: _getImage,
              child: _image == null
                  ? Container(
                      width: double.infinity,
                      height: 150,
                      decoration: BoxDecoration(
                        color: Colors.grey[300],
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Center(
                        child: Text(
                          "Upload your picture here",
                          style: TextStyle(color: Colors.grey),
                        ),
                      ),
                    )
                  : ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: Image.file(
                        _image!,
                        width: double.infinity,
                        height: 150,
                        fit: BoxFit.cover,
                      ),
                    ),
            ),
            const SizedBox(height: 20),
            TextField(
              onChanged: (value) => areaOfExpertise = value,
              decoration: InputDecoration(
                hintText: "Area of Expertise",
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(18),
                  borderSide: BorderSide.none,
                ),
                fillColor: Colors.purpleAccent.withOpacity(0.1),
                filled: true,
                prefixIcon: const Icon(Icons.work),
              ),
            ),
            const SizedBox(height: 20),
            TextField(
              onChanged: (value) => costPerSession = value,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                hintText: "Cost per Session",
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(18),
                  borderSide: BorderSide.none,
                ),
                fillColor: Colors.purpleAccent.withOpacity(0.1),
                filled: true,
                prefixIcon: const Icon(Icons.monetization_on),
              ),
            ),
            const SizedBox(height: 20),
            TextField(
              onChanged: (value) => bio = value,
              decoration: InputDecoration(
                hintText: "Bio/About",
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(18),
                  borderSide: BorderSide.none,
                ),
                fillColor: Colors.purpleAccent.withOpacity(0.1),
                filled: true,
                prefixIcon: const Icon(Icons.info),
              ),
              maxLines: 1,
            ),
            const SizedBox(height: 20),
            DropdownButtonFormField<String>(
              value: gender,
              onChanged: (String? value) {
                setState(() {
                  gender = value;
                });
              },
              decoration: InputDecoration(
                hintText: "Gender",
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(18),
                  borderSide: BorderSide.none,
                ),
                fillColor: Colors.purpleAccent.withOpacity(0.1),
                filled: true,
                prefixIcon: const Icon(Icons.person),
              ),
              items: ['Male', 'Female']
                  .map<DropdownMenuItem<String>>((String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Text(value),
                );
              }).toList(),
            ),
            if (widget.userType == 'Mentor') ...[
              const SizedBox(
                height: 15,
              ),
              const Text(
                'Availability',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(
                height: 15,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: ['M', 'T', 'W', "TH", 'FR', 'ST', 'SN'].map((e) {
                  return InkWell(
                    onTap: () {
                      if (selectedSchedule.contains(e)) {
                        selectedSchedule.remove(e);
                      } else {
                        selectedSchedule.add(e);
                      }
                      setState(() {});
                    },
                    child: Container(
                      height: 30,
                      width: 30,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: selectedSchedule.contains(e)
                            ? Colors.purpleAccent
                            : Colors.grey,
                      ),
                      padding: EdgeInsets.all(3),
                      child: Center(
                        child: Text(
                          e,
                          style: TextStyle(color: Colors.white),
                        ),
                      ),
                    ),
                  );
                }).toList(),
              ),
            ],
            const SizedBox(height: 20),
            isLoading
                ? const Center(child: CircularProgressIndicator())
                : ElevatedButton(
                    onPressed: _saveProfileToFirestore,
                    child: const Text("Save Profile"),
                  ),
          ],
        ),
      ),
    );
  }
}
