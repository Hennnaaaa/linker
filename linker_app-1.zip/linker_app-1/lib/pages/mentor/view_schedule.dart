import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:linker_app/services/user_service.dart';

class ViewSchedule extends StatefulWidget {
  const ViewSchedule({
    super.key,
    required this.id,
    required this.price,
    required this.schedule,
  });
  final String price, id;
  final List schedule;

  @override
  State<ViewSchedule> createState() => _ViewScheduleState();
}

class _ViewScheduleState extends State<ViewSchedule> {
  bool isUploading = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Book Schedule'),
      ),
      body: ListView(
        children: ['M', 'T', 'W', "TH", 'FR', 'ST', 'SN'].map((e) {
          return Padding(
            padding: const EdgeInsets.fromLTRB(10, 5, 10, 0),
            child: ListTile(
              onTap: () {
                if (widget.schedule.contains(e)) {
                  showDialog(
                    context: context,
                    builder: (context) {
                      return StatefulBuilder(
                        builder: (context, sst) {
                          return AlertDialog(
                            title: const Text('Booking confirmation'),
                            content: Text(
                                'Are you sure that you want to book this slot for \$${widget.price}?'),
                            actions: [
                              MaterialButton(
                                onPressed: () {
                                  Navigator.pop(context);
                                },
                                child: const Text('Cancel'),
                              ),
                              MaterialButton(
                                onPressed: () async {
                                  sst(() {
                                    isUploading = true;
                                  });
                                  await _createBooking(e);
                                  sst(() {
                                    isUploading = false;
                                  });
                                  if (mounted) {
                                    Navigator.pop(context);
                                    Navigator.pop(context);
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      const SnackBar(
                                        content: Text(
                                            'Booking created successfully!'),
                                        duration: Duration(seconds: 2),
                                      ),
                                    );
                                  }
                                },
                                child: const Text('Confirm'),
                              )
                            ],
                          );
                        },
                      );
                    },
                  );
                }
              },
              tileColor: widget.schedule.contains(e)
                  ? Colors.purpleAccent
                  : Colors.grey,
              title: Text(
                e,
                style: const TextStyle(
                  color: Colors.white,
                ),
              ),
              subtitle: Text(
                'Booking ${widget.schedule.contains(e) ? '' : 'NOT'} available',
                style: const TextStyle(color: Colors.white),
              ),
              trailing: Text(
                "\$${widget.price}",
                style: TextStyle(
                  fontSize: 16,
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  Future<void> _createBooking(String item) async {
    DocumentSnapshot value = await FirebaseFirestore.instance
        .collection('users')
        .doc(widget.id)
        .get();
    Map bookings = ((value.data()! as Map)['bookings']) ?? {};
    bookings.addEntries(
      {item: FirebaseAuth.instance.currentUser?.uid}.entries,
    );
    // bookings.addAll({
    //   item: FirebaseAuth.instance.currentUser?.uid,
    // });
    FirebaseFirestore.instance.collection('users').doc(widget.id).update({
      'bookings': bookings,
    });
  }
}
