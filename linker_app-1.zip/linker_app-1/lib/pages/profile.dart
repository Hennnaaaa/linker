import 'package:flutter/material.dart';
import 'package:linker_app/pages/misc.dart';
import 'package:linker_app/pages/profile_details.dart';

class MyProfileScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Profile Information"),
        backgroundColor: Colors.purpleAccent,
      ),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            _profilePicture(),
            const SizedBox(height: 20),
            _buildOption(context, "My Profile", MyProfileDetails()),
            const SizedBox(height: 10),
            _buildOption(context, "About Us", AboutUsDetails()),
            const SizedBox(height: 10),
            _buildOption(context, "Privacy Policy", PrivacyPolicyDetails()),
            const SizedBox(height: 10),
            _buildOption(
                context, "Terms and Conditions", TermsAndConditionsDetails()),
            const SizedBox(height: 10),
            _buildOption(context, "My Schedule", MyScheduleDetails()),
          ],
        ),
      ),
    );
  }

  Widget _profilePicture() {
    return Column(
      children: <Widget>[
        Container(
          width: double.infinity,
          height: 150,
          decoration: BoxDecoration(
            color: Colors.grey[300],
            borderRadius: BorderRadius.circular(12),
          ),
          child: const Center(
            child: Text(
              "Profile Picture",
              style: TextStyle(color: Colors.grey),
            ),
          ),
        ),
        const SizedBox(height: 10),
      ],
    );
  }

  Widget _buildOption(BuildContext context, String title, Widget screen) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => screen),
        );
      },
      child: Container(
        padding: const EdgeInsets.all(16),
        width: double.infinity,
        decoration: BoxDecoration(
          color: Colors.purpleAccent.withOpacity(0.2),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              title,
              style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.black),
            ),
            const Icon(Icons.arrow_forward),
          ],
        ),
      ),
    );
  }
}
