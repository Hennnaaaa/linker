import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:linker_app/pages/user_detail_view.dart';

class UserListScreen extends StatelessWidget {
  const UserListScreen({Key? key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('User List'),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('users').snapshots(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Center(
              child: Text('Error: ${snapshot.error}'),
            );
          }

          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }

          return ListView.builder(
            itemCount: snapshot.data!.docs.length,
            itemBuilder: (context, index) {
              var user = snapshot.data!.docs[index];
              return Padding(
                padding: const EdgeInsets.all(8.0),
                child: Card(
                  elevation: 3,
                  child: GestureDetector(
                    onTap: () {
                      // Navigate to UserDetailScreen on tap
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => UserDetailScreen(
                            id: user.id,
                            username: user['username'],
                            email: user['email'],
                            phoneNumber: user['phoneNumber'],
                            userType: user['userType'],
                            areaOfExpertise: user['areaOfExpertise'],
                            bio: user['bio'],
                            profileImageUrl:
                                user['imageUrl'], // Pass profile image URL
                            userData: user.data() as Map,
                          ),
                        ),
                      );
                    },
                    child: ListTile(
                      leading: CircleAvatar(
                        backgroundImage: NetworkImage(
                            user['imageUrl'] ?? ''), // Add user image
                      ),
                      title: Text(user['username']),
                      subtitle: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(user['email']),
                          Text('Phone: ${user['phoneNumber']}'),
                        ],
                      ),
                      trailing: Text(user['userType']),
                      // You can further customize the appearance of ListTile as needed
                    ),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
